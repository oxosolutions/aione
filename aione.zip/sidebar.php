<div id="sidebar" class="sidebar">
	<?php generated_dynamic_sidebar(); ?>
</div>