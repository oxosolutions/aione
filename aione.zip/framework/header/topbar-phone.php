<?php
global $theme_options;
if($theme_options['topbar_number']):
    echo '<div id="topbar-phone" class="topbar-item">'.$theme_options['topbar_number'].'</div>';
endif; ?>
