<?php
return array(
	'theme_name' => 'Aione', 
	'theme_slug' => 'aione',
	'theme_version' => '1.5.9.6',
	'required_wp_version' => '3.1',
);