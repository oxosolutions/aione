<?php
function theme_shortcode_theme_options($atts, $content = null, $code) {
	global $theme_options;
    echo "<pre>";
    print_r($theme_options);
    echo "</pre>";
	//return "<pre>".print_r($theme_options)."</pre>";
}
add_shortcode('theme_options','theme_shortcode_theme_options');


function theme_shortcode_theme($atts, $content = null, $code) {
    $theme = wp_get_theme();
    return $theme->get('Version');
}
add_shortcode('theme','theme_shortcode_theme');




function shortcode_custom_menu( $atts, $content, $tag ) {

    global $post;

    extract(shortcode_atts(array(
        'name' => '',
        'id' => '',
        'slug' => '',
        'responsive' => '',
        'mobile' => '',
        'container' => 'div',
        'container_class' => 'custom_menu_container',
        'container_id'    => '',
        'menu_class'      => 'custom_menu',

    ), $atts));

    $container_class = 'anchor_scroll '.$container_class;
    $menu_class = 'menu_scroll '.$menu_class;

    // Set defaults
    $defaults = array(
        'menu'        	  => $name,
        'container'       => $container,
        'container_class' => $container_class,
        'container_id'    => $container_id,
        'menu_class'      => $menu_class,
        'menu_id'         => '',
        'fallback_cb'     => 'wp_page_menu',
        'before'          => '',
        'after'           => '',
        'link_before'     => '',
        'link_after'      => '',
        'depth'			  => 0,
        'echo' 			  => false
    );

    // Merge user provided atts with defaults
    $atts = shortcode_atts( $defaults, $atts );

    // Create output
    $output = wp_nav_menu( $atts );

    return apply_filters( 'shortcode_custom_menu', $output, $atts, $content, $tag );

}

add_shortcode( 'menu', 'shortcode_custom_menu' );