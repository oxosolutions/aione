<?php
/**
 * Page Builder Class for Fusion Core
 *
 * @package   FusionCore
 * @author	ThemeFusion
 * @link	  http://theme-fusion.com
 * @copyright ThemeFusion
 */

define ('FUSION_BUILDER_PATH' ,  plugin_dir_url(__FILE__) );

if( ! class_exists( 'Fusion_Core_PageBuilder' ) ) {

	class Fusion_Core_PageBuilder {
		/**
		 * Instance of this class.
		 *
		 * @since	1.0.0
		 *
		 * @var	  object
		 */
		protected static $instance = null;

		/**
		 * Instances of dependent classes.
		 *
		 * @since  1.0.0
		 * 
		 * @var	array array of classes object
		 */
		protected static $instances = array();

		/**
		 * Slug of the plugin screen.
		 *
		 * @since	1.0.0
		 *
		 * @var	  string
		 */
		protected $plugin_screen_hook_suffix = null;
		
		
		/**
		 * Plugin slug.
		 *
		 * @since	2.0.0
		 *
		 * @var	  string
		 */
		protected $plugin_slug = 'fusion-core_page-builder';

		var $allowed_post_types = array('page','post','avada_faq','avada_portfolio');

		/**
		 * Initialize the plugin by loading admin scripts & styles and adding a
		 * settings page and menu.
		 *
		 * @since	 1.0.0
		 */
		 
		 
		private function __construct() {

			// Load admin style sheet and JavaScript.
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
			add_action( 'admin_print_footer_scripts', array( $this, 'enqueue_wp_editor_scripts' ) );

			//load editor
			add_action( 'edit_form_after_editor', array( $this, 'get_builder_canvas' ),1000 );
			//register AJAX actions
			add_action( 'wp_ajax_fusion_pallete_elements', array( $this,'get_pallete_elements') );
			add_action( 'wp_ajax_fusion_update_builder_data', array( $this,'update_builder_data') );
			add_action( 'wp_ajax_fusion_custom_tabs', array( $this,'custom_tabs_handler') );
			add_action( 'wp_ajax_fusion_get_shortcodes', array( $this,'get_shortocodes_from_json') );
			add_action( 'wp_ajax_fusion_content_to_elements', array( $this,'get_elements_from_content') );
			//register actions to save builder content revisions
			add_action( 'save_post', array( $this, 'save_fusion_revisions_with_post' ) );
			add_action( 'wp_restore_post_revision', array ( $this,  'fusion_restore_revision' ), 10, 2 );
			add_filter( '_wp_post_revision_fields', array ( $this, 'fusion_revision_fields' ) );
			add_filter( '_wp_post_revision_field_fb_content', array ( $this,  'fusion_revision_field' ), 10, 2 );
			// Load page builder classes
			require_once( 'page-builder/classes/class-ui.php' );

			$settings['allowed_post_types'] = $this->allowed_post_types;
			// Create a new instance of page builder classes
			$instances['ui'] = Fusion_Core_PageBuilder_UI::get_instance( $settings );
			
			//load API and required files
			require_once ( 'page-builder/api/Palette.php' );
			
			//load required classes
			require_once ( 'page-builder/classes/class-custom-templates.php' );
			require_once ( 'page-builder/classes/class-prebuilt-templates.php' );
			require_once ( 'page-builder/classes/class-shortcodes-parser.php' );
			require_once ( 'page-builder/classes/class-fusion-reversal.php' );
			
		}
		
		/**
		 * Return an instance of this class.
		 *
		 * @since	 1.0.0
		 *
		 * @return	object	A single instance of this class.
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;

		}

		/**
		 * Register and enqueue admin-specific style sheet.
		 *
		 * @since	 1.0.0
		 *
		 * @return	null	Return early if no settings page is registered.
		 */
		public function enqueue_admin_styles() {

			$screen 			= get_current_screen();
			$allowed_screens 	= $this->allowed_post_types;
			if ( in_array( $screen->id, $allowed_screens) ) {
				wp_enqueue_style( 'wp-color-picker' ); // for color picker
				wp_enqueue_style( 'fusionb_icomoon', plugins_url( 'page-builder/assets/fonts/icomoon.css', __FILE__ ), array(), FusionCore_Plugin::VERSION );
				wp_enqueue_style( 'fusionb_jq-ui-style', plugins_url( 'page-builder/assets/css/jquery/jquery-ui-skeleton.css', __FILE__ ), array(), FusionCore_Plugin::VERSION );
				wp_enqueue_style( 'fusionb_builder-style', plugins_url( 'page-builder/assets/css/application.css', __FILE__ ), array(), FusionCore_Plugin::VERSION );
			}

		}

		/**
		 * Register and enqueue admin-specific JavaScript.
		 *
		 * @since	 1.0.0
		 *
		 * @return	null	Return early if no settings page is registered.
		 */
		public function enqueue_admin_scripts() {
			global $wp_version;
			$screen = get_current_screen();
			$allowed_screens 	= $this->allowed_post_types;
			if ( in_array( $screen->id, $allowed_screens) ) {
				$fusionb_vars = array(
					'url' => get_home_url(),
					'includes_url' => includes_url()
				);

				wp_register_script( 'fusionb_wpeditor_init', plugins_url( 'page-builder/assets/js/js-wp-editor.js', __FILE__ ), array( 'jquery' ), FusionCore_Plugin::VERSION, true );
				wp_localize_script( 'fusionb_wpeditor_init', 'fusionb_vars', $fusionb_vars );
				wp_enqueue_script( 'fusionb_wpeditor_init' );
				wp_enqueue_script( 'fusionb_admin-script', plugins_url( 'page-builder/assets/js/admin.js', __FILE__ ), array( 'jquery' ), FusionCore_Plugin::VERSION );
				wp_enqueue_script( 'fusionb_custom-templates-script', plugins_url( 'page-builder/assets/js/custom-templates.js', __FILE__ ), array( 'jquery' ), FusionCore_Plugin::VERSION );
				wp_enqueue_script( 'fusionb_prebuilt-templates-script', plugins_url( 'page-builder/assets/js/pre-built-templates.js', __FILE__ ), array( 'jquery' ), FusionCore_Plugin::VERSION );
				wp_enqueue_script( 'wp-color-picker'); //for wp color picker
				//Page builder core scripts
				wp_enqueue_script( 'jquery-ui-core' );
				wp_enqueue_script( 'jquery-ui-sortable' );
				wp_enqueue_script( 'jquery-ui-draggable' );
				wp_enqueue_script( 'jquery-ui-droppable' );
				wp_enqueue_script( 'jquery-ui-dialog' );
				wp_enqueue_script( 'jquery-ui-button' );
				wp_enqueue_script( 'jquery-ui-tabs' );
				
				$handle = 'fluidVids.js';
				$list = 'enqueued';
				wp_enqueue_script( 'backbone' );
				wp_enqueue_script( 'underscore' );
				wp_enqueue_script( 'fusionb_bk-handlers', plugins_url( 'page-builder/assets/js/handlebars.js', __FILE__ ), array( 'jquery' ), FusionCore_Plugin::VERSION );
				wp_enqueue_script( 'fusionb_fusion-history', plugins_url( 'page-builder/assets/js/fusion-history.js', __FILE__ ), array(  ), FusionCore_Plugin::VERSION , true);
				wp_enqueue_script( 'fusionb_fusion-parser', plugins_url( 'page-builder/assets/js/fusion-parser.js', __FILE__ ), array(  ), FusionCore_Plugin::VERSION , true);
				wp_enqueue_script( 'fusionb_dd-parser', plugins_url( 'page-builder/assets/js/dd-element-parser.js', __FILE__ ), array(  ), FusionCore_Plugin::VERSION , true);
				wp_enqueue_script( 'fusionb_builder-helper', plugins_url( 'page-builder/assets/js/DdHelper.js', __FILE__ ), array( 'jquery' ), FusionCore_Plugin::VERSION, true);
				wp_enqueue_script( 'fusionb_builder-cat', plugins_url( 'page-builder/assets/js/category.js', __FILE__ ), array( ), FusionCore_Plugin::VERSION , true);
				wp_enqueue_script( 'fusionb_builder-palette', plugins_url( 'page-builder/assets/js/palette.js', __FILE__ ), array(), FusionCore_Plugin::VERSION , true);
				wp_enqueue_script( 'fusionb_builder-editor', plugins_url( 'page-builder/assets/js/editor.js', __FILE__ ), array(), FusionCore_Plugin::VERSION , true);
				wp_enqueue_script( 'fusionb_builder-app', plugins_url( 'page-builder/assets/js/application.js', __FILE__ ), array(  ), FusionCore_Plugin::VERSION , true);
				wp_enqueue_script( 'fusionb_builder-previews', plugins_url( 'page-builder/assets/js/fusion-previews.js', __FILE__ ), array(  ), FusionCore_Plugin::VERSION , true);

			}

		}
		public function enqueue_wp_editor_scripts() {
			$screen = get_current_screen();
			$allowed_screens 	= $this->allowed_post_types;
			if ( in_array( $screen->id, $allowed_screens) ) {
				if ( ! class_exists( '_WP_Editors' ) ) {
					require( ABSPATH . WPINC . '/class-wp-editor.php' );
				}

				$set = _WP_Editors::parse_settings( 'fusionb_id', array() );

				if ( !current_user_can( 'upload_files' ) ) {
					$set['media_buttons'] = false;
				}

				if ( $set['media_buttons'] ) {
					wp_enqueue_script( 'thickbox' );
					wp_enqueue_style( 'thickbox' );
					wp_enqueue_script('media-upload');

					$post = get_post();
					if ( ! $post && ! empty( $GLOBALS['post_ID'] ) )
						$post = $GLOBALS['post_ID'];

					wp_enqueue_media( array(
						'post' => $post
					) );
				}

				_WP_Editors::editor_settings( 'fusionb_id', $set );
			}
		}
		/**
		 * function to return Json response for all Palette/Editor elements
		 *
		 * @since	 2.0.0
		 *
		 * @return	JSON data   
		 *
		 * @param	  Post data [action],[category] 
		 */
		public function get_pallete_elements () {
			if(isset($_POST['category']) && $_POST['category'] == 'Palette') { //if pallete required
				try {
					header("Content-Type: application/json");
					
					$palette = new Palette();
					$elements = $palette->to_JSON();
					echo $elements;
				} catch(Exception $e) {
					echo '{"error":{"text":'. $e->getMessage() .'}}'; 
				}
			} else {	//if editor elements required
				try  {
					header("Content-Type: application/json");
					$instance 	= $_POST['instance'];
					$editor 	= new Editor ($instance );
					$elements 	= $editor->to_JSON();
					echo $elements;
				} catch(Exception $e)  {
					echo '{"error":{"text":'. $e->getMessage() .'}}'; 
				}
			}
			exit();
		}
		/**
		 * Function to update builder content
		 *
		 * @since	 2.0.0
		 *
		 * @return	JSON data   
		 *
		 * @Param	  Post Data ['model'] 
		 *
		 * @Param	  Post Data ['instance']
		 */
		function update_builder_data () {
			
			$instance 	= $_POST['instance'];
			$model 		= $_POST['model'];
			$model 		= str_replace ( "\'","'", $model );
			$model 		= str_replace ( '\"','"', $model );
			$model 		= preg_replace ( "~\\\\+([\"\'\\x00\\\\])~", '\\"', $model );
			$model		= json_decode($model);
			$state		= $_POST['state'];
			//save state if builder active or WP default editor
			update_post_meta ( $instance , 'fusion_builder_status', array( $state ) );

			$resonse 	= update_post_meta ( $instance , 'fusion_builder_content', $model );
			
			if ( sizeof ( $model ) < 1) {
				$resonse = delete_post_meta ( $instance , 'fusion_builder_content', $model );
			}
			
			header("Content-Type: application/json");
			if ( $resonse != false ) {
				echo '{"success":{"text":',json_encode(__('Builder content have been updated successfully.', 'fusion-core')),'}}'; 
			} else {
				echo '{"error":{"text":',json_encode(__('There was some error, could not update fusion builder data. Please try again.', 'fusion-core')),'}}';
			}
			exit();
		}
		/**
		 * Function to hanlde custom and pre-built templates  
		 *
		 * @since	 2.0.0
		 *
		 * @return	Content  
		 *
		 * @Param	  Action, InstanceID   :: Post Params
		 */
		public function custom_tabs_handler () {
			
			$action = $_POST['post_action'];
			
			switch ( $action ) {
				
				case 'get_custom_templates':
				
					$custom_templates 	= new Fusion_Core_Custom_Templates();
					echo $custom_templates->get_custom_templates();
					exit();
					
				break;
				
				case 'get_prebuilt_templates':
				
					$prebuilt_templates = new Fusion_Core_Prebuilt_Templates();
					echo $prebuilt_templates->get_prebuilt_templates();
					exit();
					
				break;
				
				case 'save_custom_template' :
					$content			= array();
					$custom_templates 	= new Fusion_Core_Custom_Templates();
					$response 			= $custom_templates->save_single_template();
					header("Content-Type: application/json");
					if ($response) {
						$content['message'] 			= '{"success":{"text":'.json_encode(__('Temaplte have been saved successfully.', 'fusion-core')).'}}';
						$custom_templates 				= new Fusion_Core_Custom_Templates();
						$content['custom_templates'] 	= $custom_templates->get_custom_templates();
						echo json_encode( $content );
					} else {
						echo '{"error":{"text":',json_encode(__('There was some error, could not add custom template. Kindly try again.', 'fusion-core')),'}}';
					}
					exit();
				break;
				
				case 'delete_custom_template':
					$content			= array();
					$custom_templates 	= new Fusion_Core_Custom_Templates();
					$response 			= $custom_templates->delete_single_template();
					header("Content-Type: application/json");
					if ($response) {
						$content['message'] 			= '{"success":{"text":'.json_encode(__('Template deleted successfully.', 'fusion-core')).'}}';
						$custom_templates 				= new Fusion_Core_Custom_Templates();
						$content['custom_templates'] 	= $custom_templates->get_custom_templates();
						echo json_encode( $content );
					} else {
						echo '{"error":{"text":',json_encode(__('There was some error, could not delete custom template. Kindly try again.', 'fusion-core')),'}}';
					}
					exit();
				break;
				
				case 'load_custom_template':
					$custom_templates 	= new Fusion_Core_Custom_Templates();
					$template			= $custom_templates->get_single_template();
					
					if ( $template != false ) {
						echo $template;
					} else {
						echo json_encode( array() );
					}
					exit();
					
				break;
				
				case 'load_prebuilt_template':
				
					$prebuilt_templates 	= new Fusion_Core_Prebuilt_Templates();
					$template				= $prebuilt_templates->get_single_template();
					
					if ( $template != false ) {
						echo $template;
					} else {
						echo json_encode( array() );
					}
					exit();
					
				break;
				
				case 'get_custom_and_prebuilt_templates':
					$content = array();
					$custom_templates 				= new Fusion_Core_Custom_Templates();
					$content['custom_templates'] 	= $custom_templates->get_custom_templates();
					$prebuilt_templates 			= new Fusion_Core_Prebuilt_Templates();
					$content['prebuilt_templates'] 	= $prebuilt_templates->get_prebuilt_templates();
					header("Content-Type: application/json");
					echo json_encode( $content) ;
					exit();
				break;
				
			}
			
			
		}
		public function get_elements_from_content() {
			
			echo Fusion_Core_Reversal::content_to_elements( $_POST['content'] );
			exit();
		}
		/**
		 * Function to get shortcodes from JSON content 
		 *
		 * @since	 2.0.0
		 *
		 * @return	NULL  
		 *
		 * @Param	  POST['data']
		 */
		public function get_shortocodes_from_json ( ) {
			$builder_data 		= $_POST['builder_data'];
			$builder_data 		= str_replace ( "\'","'", $builder_data );
			$builder_data 		= str_replace ( '\"','"', $builder_data );
			$builder_data 		= preg_replace ( "~\\\\+([\"\'\\x00\\\\])~", '\\"', $builder_data );
			$builder_data		= json_decode( $builder_data );
			
			Fusion_Core_Shortcodes_Parser::set_content( $builder_data );
			
			$response 			= Fusion_Core_Shortcodes_Parser::parse_column_options( );
			
			echo $response;
			exit();
			
		}
		/**
		 * Function to save fusion builder content revisions 
		 *
		 * @since	 2.0.0
		 *
		 * @return	NULL  
		 *
		 * @Param	  Post ID 
		 */
		public function save_fusion_revisions_with_post ( $post_id ) {
			
			if( isset( $_POST['fusion_builder_status'] ) && $_POST['fusion_builder_status'] ) {
				update_post_meta( $post_id , 'fusion_builder_status' , $_POST['fusion_builder_status'] );
			}

			$parent_id = wp_is_post_revision( $post_id );
			
			if ( $parent_id ) {
				$parent  	= get_post( $parent_id );
				$FB_content = get_post_meta( $parent->ID, 'fusion_builder_content', true );

				if ( false !== $FB_content )
					add_metadata( 'post', $post_id, 'FB_content', $FB_content );

			}

		}
		/**
		 * Function to restore fusion builder content along with revision
		 *
		 * @since	 2.0.0
		 *
		 * @return	NULL   
		 *
		 * @Param	  Post ID, Revision ID 
		 */
		public function fusion_restore_revision ( $post_id, $revision_id ) {
			
			$post	 					= get_post( $post_id );
			$revision 					= get_post( $revision_id );
			$FB_content  				= get_metadata( 'post', $revision->ID, 'FB_content', true );
			
			if ( false !== $FB_content )
				update_post_meta( $post_id, 'fusion_builder_content', $FB_content );
			else
				delete_post_meta( $post_id, 'fusion_builder_content' );
				
		}
		/**
		 * Function to show revision on revisions screen
		 *
		 * @since	 2.0.0
		 *
		 * @return	Array data   
		 *
		 * @Param	  Revision fields array 
		 */
		public function fusion_revision_fields ( $revision_fields ) {

			$revision_fields['fb_content'] = __('Fusion builder elements', 'fusion-core');

			return $revision_fields;
		}
		/**
		 * comparator function helper for revisions
		 *
		 * @since	 2.0.0
		 *
		 * @return	String data   
		 *
		 * @Param	  value, field name
		 */
		public function fusion_revision_field ( $value, $field ) {
			
			return sprintf(__('# of elements: %s', 'fusion-core'), count (  ( $value ) ));
		}
		/**
		 * get editor convas ready.
		 *
		 * @since	 2.0.0
		 *
		 * @return	null	includes script.
		 */
		public function get_builder_canvas() {
			
			$screen = get_current_screen();
			$allowed_screens 	= $this->allowed_post_types;
			if ( in_array( $screen->id, $allowed_screens) ) {
				require ( plugin_dir_path( __FILE__ ). 'page-builder/views/builder.php' );
			}
		}
		

	}
	

}